class Constant {
  static const String baseUrl = "https://khakestari.wiremockapi.cloud";
  static const String token = "get api token here";
}
